Nano96 firmware — current state

This is a basic/starting ZMK shield, not a verified working build yet.
It compiles conceptually but has several placeholders that need
confirming against the real board once it's assembled:

- [ ] Row/col GPIO pin numbers in nano96.overlay (row-gpios / col-gpios)
- [ ] MCP23017 I2C address (assumed 0x20, confirm against schematic)
- [ ] SSD1306 OLED I2C address (assumed 0x3c)
- [ ] Encoder A/B pins
- [ ] WS2812 data pin for per-key RGB
- [ ] Matrix transform (columns/rows/map) — currently a 7x14 placeholder,
      not the real 97-key physical layout
- [ ] Keymap layout — currently a generic QWERTY-ish placeholder,
      not matched to actual keycap positions
- [ ] Function layer bindings — mostly empty, needs RGB/media/BT keys

Once the board arrives: flash, use `zmk,kscan` debug logging to confirm
each switch reports the correct row/col, then update the matrix
transform and keymap to match reality.
